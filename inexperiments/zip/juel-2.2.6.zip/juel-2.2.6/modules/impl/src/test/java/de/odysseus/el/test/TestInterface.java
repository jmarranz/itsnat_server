package de.odysseus.el.test;

public interface TestInterface {
	public int fourtyTwo(); 
}
