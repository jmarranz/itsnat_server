/*
  ItsNat Java Web Application Framework
  Copyright (C) 2007-2011 Jose Maria Arranz Santamaria, Spanish citizen

  This software is free software; you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as
  published by the Free Software Foundation; either version 3 of
  the License, or (at your option) any later version.
  This software is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Lesser General Public License for more details. You should have received
  a copy of the GNU Lesser General Public License along with this program.
  If not, see <http://www.gnu.org/licenses/>.
*/

package org.itsnat.impl.comp;

import org.itsnat.comp.ItsNatHTMLComponentManager;
import org.itsnat.comp.ItsNatHTMLElementComponent;
import org.itsnat.comp.ItsNatHTMLElementComponentUI;
import org.itsnat.core.NameValue;
import org.itsnat.impl.comp.mgr.ItsNatStfulDocComponentManagerImpl;
import org.w3c.dom.html.HTMLElement;

/**
 * No vincular con ItsNatHTMLDocument pues otros namespaces podr�n tener elementos HTML
 *
 * @author jmarranz
 */
public abstract class ItsNatHTMLElementComponentImpl extends ItsNatElementComponentImpl implements ItsNatHTMLElementComponent
{

    /**
     * Creates a new instance of ItsNatHTMLElementComponentImpl
     */
    public ItsNatHTMLElementComponentImpl(HTMLElement node,NameValue[] artifacts,ItsNatStfulDocComponentManagerImpl componentMgr)
    {
        super(node,artifacts,componentMgr);
    }

    public Object createDefaultStructure()
    {
        // Ninguno de los componentes hijos usa estructura a medida, ni siquiera
        // los <select> pues la estructura es r�gida incluyendo <option> que
        // s�lo admite texto como hijo
        return null;
    }

    public ItsNatStfulDocComponentManagerImpl getItsNatStfulDocComponentManager()
    {
        return (ItsNatStfulDocComponentManagerImpl)componentMgr;
    }

    public ItsNatHTMLComponentManager getItsNatHTMLComponentManager()
    {
        return getItsNatStfulDocComponentManager();
    }

    public ItsNatHTMLElementComponentUI getItsNatHTMLElementComponentUI()
    {
        return (ItsNatHTMLElementComponentUI)compUI;
    }

    public HTMLElement getHTMLElement()
    {
        return (HTMLElement)node;
    }
}
