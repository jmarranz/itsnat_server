/*
  ItsNat Java Web Application Framework
  Copyright (C) 2007-2011 Jose Maria Arranz Santamaria, Spanish citizen

  This software is free software; you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as
  published by the Free Software Foundation; either version 3 of
  the License, or (at your option) any later version.
  This software is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Lesser General Public License for more details. You should have received
  a copy of the GNU Lesser General Public License along with this program.
  If not, see <http://www.gnu.org/licenses/>.
*/

package org.itsnat.impl.core.browser.opera;

import java.util.Map;
import org.itsnat.impl.core.browser.*;
import org.itsnat.impl.core.doc.ItsNatStfulDocumentImpl;
import org.itsnat.impl.core.servlet.ItsNatServletRequestImpl;
import org.w3c.dom.html.HTMLElement;

/**
  En Opera el unload no se dispara siempre y onbeforeunload no est� definido
  http://www.quirksmode.org/bugreports/archives/2004/11/load_and_unload.html

 * @author jmarranz
 */
public abstract class BrowserOpera extends BrowserW3C
{
    public static final int OPERA_DESKTOP = 1;
    public static final int OPERA_MINI = 2;
    public static final int OPERA_MOBILE = 3;

    /** Creates a new instance of BrowserOpera */
    public BrowserOpera(String userAgent)
    {
        super(userAgent);

        this.browserType = OPERA;
    }

    public static BrowserOpera createBrowserOpera(String userAgent)
    {
        if (BrowserOperaMini.isOperaMini(userAgent))
            return new BrowserOperaMini(userAgent);
        else if (BrowserOperaMobile.isOperaMobile9(userAgent))
            return new BrowserOperaMobile(userAgent);
        else
            return new BrowserOperaDesktop(userAgent);
    }

    public static boolean isOpera(String userAgent,ItsNatServletRequestImpl itsNatRequest)
    {
        return (userAgent.indexOf("Opera") != -1);
    }

    @Override
    public boolean hasBeforeUnloadSupport(ItsNatStfulDocumentImpl itsNatDoc)
    {
        return false; // Tampoco en HTML
    }

    public boolean isReferrerReferenceStrong()
    {
        // El back/forward est� cacheado en el cliente.
        return true;
    }

    public boolean isCachedBackForward()
    {
        // Opera Mini: s�lo tiene Back
        return true;
    }

    public boolean isClientWindowEventTarget()
    {
        return true;
    }
    

    public boolean isDOMContentLoadedSupported()
    {
        return true;
    }

    public boolean isBlurBeforeChangeEvent(HTMLElement formElem)
    {
        // Opera Mini no lanza el evento blur, pero si lo hiciera
        // lo har�a como sus "hermanos".
        return false;
    }

    public boolean canNativelyRenderOtherNSInXHTMLDoc()
    {
        return true; // Soporta SVG al menos.
    }

    public boolean isInsertedSVGScriptNotExecuted()
    {
        return false;
    }

    public boolean isTextAddedToInsertedSVGScriptNotExecuted()
    {
        // En Opera 9 desktop el texto del script se ejecuta si
        // se inserta junto al elemento <script>, no funciona si es despu�s
        // En Opera 10 funciona bien en ambos casos, la soluci�n al problema
        // es compatible con que funcione bien pues en la reinserci�n no se ejecuta de nuevo.
        // En Opera Mobile 9.5 y 9.7 Win Mobile funcionan bien con esta soluci�n.
        // En Opera Mobile 9.5 UIQ el navegador es un visor de SVG sin scripts o funciona mal por lo menos.
        // En Opera Mini 4 no hay problema pues el render siempre es lo �ltimo de Opera.
        return true;
    }    
    
    public boolean hasHTMLCSSOpacity()
    {
        return true;
    }    
    
    public Map<String,String[]> getHTMLFormControlsIgnoreZIndex()
    {
        // En teor�a todos los elementos no ignoran el z-index, sin embargo
        // aunque Opera Mobile 9.x est� dise�ado para pantallas t�ctiles,
        // hasta cierto punto soporta navegaci�n por cursores,
        // y he descubierto que a trav�s de los cursores podemos llegar y "pulsar"
        // todos los elementos con listeners de layers por debajo, tanto en Win CE como en Symbian.

        // El problema es que cualquier elemento no form con
        // un listener "click" es susceptible tambi�n de llegarse a �l usando
        // los cursores, desafortunadamente "el cuadro de foco" se muestra
        // al pasar por el mismo.

        // No consideramos ese caso pues su pulsaci�n es premeditada o accidental
        // y en ese caso lo que hacemos es lanzar una excepci�n.

        return null;
    }    
}
