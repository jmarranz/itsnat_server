/*
  ItsNat Java Web Application Framework
  Copyright (C) 2007-2011 Jose Maria Arranz Santamaria, Spanish citizen

  This software is free software; you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as
  published by the Free Software Foundation; either version 3 of
  the License, or (at your option) any later version.
  This software is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Lesser General Public License for more details. You should have received
  a copy of the GNU Lesser General Public License along with this program.
  If not, see <http://www.gnu.org/licenses/>.
*/

package org.itsnat.impl.core.browser.opera;

import java.util.Map;
import org.w3c.dom.html.HTMLElement;

/**
 * Soportado desde la versi�n 9 (9.26 al menos)
 *
 * Ejemplos user agent: (parece que "Presto" se introdujo en 9.6 seg�n listado de botsvsbrowsers.com)
 *
 *  "Opera/9.26 (Windows NT 5.1; U; en)"
 *  "Opera/9.63 (Windows NT 5.1; U; en) Presto/2.1.1"
 *  Opera 10: "Opera/9.80 (Windows NT 5.1; U; en) Presto/2.2.15 Version/10.00"
 *            Notar que no aparece el "10" esto es para evitar confundir a algunos "browser sniffers" que lo detectar�an como una versi�n antigua (la v1 seguramente)
 *
 * @author jmarranz
 */
public class BrowserOpera9Desktop extends BrowserOpera9
{
    /**
     * Creates a new instance of BrowserOpera9Desktop
     */
    public BrowserOpera9Desktop(String userAgent)
    {
        super(userAgent);

        this.browserSubType = OPERA_DESKTOP;
    }

    public boolean isMobile()
    {
        return false;
    }

    public boolean isCachedBackForwardExecutedScripts()
    {
        // Hagas lo que hagas Opera 9 no recarga la p�gina ante un back/forward
        // (ignora headers etc), por ahora parece innegociable:
        // http://my.opera.com/yngve/blog/2007/02/27/introducing-cache-contexts-or-why-the
        // Al menos he conseguido que el evento onload se emita enviando:
        // http://www.experts-exchange.com/Programming/Languages/Scripting/JavaScript/Q_21907326.html

        return true;
    }

    public boolean isFocusOrBlurMethodWrong(String methodName,HTMLElement formElem)
    {
        return false;
    }

    public Map getHTMLFormControlsIgnoreZIndex()
    {
        return null;
    }

    public boolean hasHTMLCSSOpacity()
    {
        return true;
    }
}
