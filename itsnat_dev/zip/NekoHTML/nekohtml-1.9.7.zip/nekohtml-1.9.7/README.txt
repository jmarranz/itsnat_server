NekoHTML Readme
===============

Building
--------

You can build NekoHTML by typing the following command:

  > ant (target ...)

The default target will build the entire package.

To build NekoHTML, you need Ant and Xerces2. Place the Xerces jar 
files in the lib/ directory.

Documentation
-------------

The documentation for NekoHTML is located at the following URL:

  doc/index.html

Contact Information
-------------------

Andy Clark <andyc@apache.org>