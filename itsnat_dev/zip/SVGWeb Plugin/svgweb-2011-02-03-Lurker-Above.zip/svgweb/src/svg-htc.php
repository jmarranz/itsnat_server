<?php
header("Content-type: text/x-component");
include "svg.htc";
?>